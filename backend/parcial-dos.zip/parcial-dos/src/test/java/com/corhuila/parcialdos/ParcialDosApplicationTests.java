package com.corhuila.parcialdos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParcialDosApplicationTests {

	@Test
	void contextLoads() {
	}

}
